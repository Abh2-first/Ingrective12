import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="flex justify-between items-center bg-white/70 backdrop-blur-md px-8 py-4 shadow-md sticky top-0 z-50">
      <h1 className="text-2xl font-bold text-blue-700">🍎 Can Read and Eat</h1>
      <div className="flex gap-4 text-gray-700 font-medium">
        <Link href="/">Home</Link>
        <Link href="/scan">Scan</Link>
        <Link href="/profile">Profile</Link>
        <Link href="/sample">Sample</Link>
        <Link href="/harmful">Harmful</Link>
        <Link href="/about">About</Link>
        <Link href="/contact">Contact</Link>
      </div>
    </nav>
  );
}