export default function Footer() {
  return (
    <footer className="text-center bg-white/70 backdrop-blur-md py-4 shadow-inner mt-10">
      <p className="text-blue-700 font-semibold">
        © {new Date().getFullYear()} Can Read and Eat — “Read Before You Eat”
      </p>
      <p className="text-gray-600 text-sm">Made with ❤️ by Abhay</p>
    </footer>
  );
}