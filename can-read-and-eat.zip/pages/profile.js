export default function Profile() {
  return (
    <div className="p-10 text-center">
      <h1 className="text-3xl font-bold text-blue-700 mb-4">Your Profile</h1>
      <p>Track your scans and preferences here (coming soon!)</p>
    </div>
  );
}