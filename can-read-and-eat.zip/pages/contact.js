export default function Contact() {
  return (
    <div className="p-10 text-center">
      <h1 className="text-3xl font-bold text-blue-700 mb-4">Contact Us</h1>
      <p>Email: <a href="mailto:support@canreadandeat.com" className="text-blue-600 underline">support@canreadandeat.com</a></p>
      <p>We’d love your feedback and ideas!</p>
    </div>
  );
}