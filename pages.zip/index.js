export default function Home() {
  return (
    <section className="text-center py-16 px-6">
      <h1 className="text-4xl font-bold text-blue-800 mb-4">
        Welcome to 🍎 Can Read and Eat
      </h1>
      <p className="text-lg max-w-2xl mx-auto">
        Scan your packaged food and understand its ingredients in simple language.
        We’ll help you know how healthy your choice really is.
      </p>
      <img
        src="/foodscan.png"
        alt="Food Scan"
        className="mx-auto mt-10 rounded-xl shadow-lg max-w-sm"
      />
    </section>
  );
}