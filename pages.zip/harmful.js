export default function Harmful() {
  const list = [
    { name: "High Fructose Corn Syrup", effect: "Increases obesity & diabetes risk" },
    { name: "Sodium Nitrate", effect: "Linked to heart issues" },
    { name: "Artificial Colors (E102, E110)", effect: "Can trigger allergies" },
    { name: "Trans Fats", effect: "Raise bad cholesterol" },
  ];
  return (
    <div className="p-10">
      <h1 className="text-3xl font-bold text-blue-700 mb-6 text-center">🚫 Harmful Ingredients</h1>
      <ul className="space-y-4">
        {list.map((item, i) => (
          <li key={i} className="bg-white rounded-lg shadow p-4">
            <b>{item.name}</b> — {item.effect}
          </li>
        ))}
      </ul>
    </div>
  );
}