import { useState } from "react";

export default function Scan() {
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleUpload = async () => {
    if (!file) return alert("Please select an image!");
    setLoading(true);
    const formData = new FormData();
    formData.append("image", file);
    try {
      const res = await fetch("https://Tigerabhay-Ingrective5.hf.space/run/predict", { method: "POST", body: formData });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      alert("Error analyzing image");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="text-center py-10 px-4">
      <h1 className="text-3xl font-semibold text-blue-700 mb-2">Scan Your Product</h1>
      <p className="text-gray-600 mb-6">Upload a clear photo of the food label to analyze ingredients.</p>
      <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files[0])} className="border p-2 rounded-md" />
      <button onClick={handleUpload} className="ml-3 px-5 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
        {loading ? "Analyzing..." : "Analyze"}
      </button>
      {result && (
        <div className="mt-10 bg-white shadow-md rounded-lg p-6 inline-block text-left">
          <h2 className="text-xl font-bold mb-2 text-blue-700">Results</h2>
          <p><b>Ingredients:</b> {result.ingredients || "N/A"}</p>
          <p><b>Health Score:</b> {result.score || "N/A"}</p>
        </div>
      )}
    </section>
  );
}